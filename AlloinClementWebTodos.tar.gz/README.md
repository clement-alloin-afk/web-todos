# Travail web: Todos

## Backend
* API REST avec le framework django-rest-framework
* Le système d'authentification utiliser les JSON WEB TOKEN
* Chaque utilisateur possède ses propres todos (qui possèdent un champ texte value et un boolean checked). 

## Frontend
* Avec vue.js
* Tests avec Cypress
