<template>
  <div>
  <div class="container text-dark">
    <div class="row justify-content-md-center">
      <div class="col-md-5 p-3 login justify-content-md-center">
        <h1 class="h3 mb-3 font-weight-normal text-center">Please sign in</h1>

        <p class="incorrectId" v-if="incorrectAuth"> - Mauvais identifiants -</p>
        <form v-on:submit.prevent="login">
          <div class="form-group">
            <input type="text" name="username" id="user" v-model="username" class="username-input form-control" placeholder="Username">
          </div>
          <div class="form-group">
            <input type="password" name="password" id="pass" v-model="password" class="password-input form-control" placeholder="Password">
          </div>
          <button type="submit" class="btn-connexion btn btn-lg btn-primary btn-block">Login</button>
        </form>
        
      </div>
    </div>
  </div>
  </div>
</template>

<script>
  export default {
    name: 'login',
    data () {
      return {
        username: '',
        password: '',
        incorrectAuth: false
      }
    },
    methods: {
      login () { 
        this.$store.dispatch('userLogin', {
          username: this.username,
          password: this.password
        })
        .then(() => {
          this.$router.push({ name: 'todos' })  
        })
        .catch(err => {
          console.log(err)
          this.incorrectAuth = true
        })
        }
      }
  }
</script>

<style>
  body { 
  background-color:#f4f4f4;
  }
  .login{
    background-color:#fff;
    margin-top:10%;
  }
  form-control {
    padding: 25px 10px;
  }
</style>